import logging
import os

from dbrepo.api.dto import Database, View, ViewColumn, ColumnType

datasource_uid = os.getenv('JSON_DATASOURCE_NAME', 'dbrepojson0')

base_url = os.getenv('BASE_URL', 'http://localhost')

statistics_row_title = 'Generated Statistics'

disclaimer = 'Generic auto-generated chart'

number_types = [ColumnType.SERIAL, ColumnType.BIT, ColumnType.SMALLINT, ColumnType.MEDIUMINT, ColumnType.INT,
                ColumnType.BIGINT, ColumnType.FLOAT, ColumnType.DOUBLE, ColumnType.DECIMAL]

time_types = [ColumnType.DATE, ColumnType.TIME, ColumnType.TIMESTAMP, ColumnType.YEAR]

bool_types = [ColumnType.TINYINT, ColumnType.BOOL]

section_height = 3 * 8


def get_panels(dashboard: dict, database: Database) -> [dict]:
    panels = dashboard['panels']
    try:
        end_index = _get_start_index(dashboard)
        logging.debug(f'splicing managed panels after index: {end_index}')
        panels = panels[:end_index]
    except ValueError:
        logging.warning(f'No managed panels found')
    original_panels_size = len(panels)
    panels.append(map_row(statistics_row_title, 0, 0))  # statistics row
    for i, view in enumerate(database.views):
        # section
        panels.append(map_row(view.name, 0, i * section_height + 0))
        panels.append(map_overview_panel(database.id, view.id, 0, i * section_height + 4))
        panels.append(map_rows_panel(database.id, view.id, 18, i * section_height + 0))
        panels.append(map_columns_panel(database.id, view.id, 18, i * section_height + 4))
        panels.append(map_statistics_panel(database.id, view.id, h=8, w=12, x=0, y=i * section_height + 8))
        panels.append(map_histogram_panel(database.id, view, h=8, w=12, x=12, y=i * section_height + 8))
        panels.append(map_timeseries_panel(database.id, view, h=8, w=8, x=0, y=i * section_height + 16))
        panels.append(map_pie_panel(database.id, view, h=8, w=8, x=8, y=i * section_height + 16))
    logging.info(f'Added {len(panels) - original_panels_size} managed panel(s)')
    return panels


def _get_start_index(dashboard: dict) -> int | None:
    return [panel['title'] for panel in dashboard['panels']].index(statistics_row_title)


def map_column_conversion(column: ViewColumn) -> dict:
    destinationType = 'string'
    dateFormat = None
    if column.type in number_types:
        destinationType = 'number'
    elif column.type in time_types:
        destinationType = 'time'
        if column.type == ColumnType.YEAR:
            dateFormat = 'YYYY'
        elif column.type == ColumnType.TIME:
            dateFormat = 'HH:mm:ss'
        else:
            dateFormat = 'YYYY-MM-dd'
    elif column.type in bool_types:
        destinationType = 'boolean'
    return dict(targetField=column.internal_name,
                destinationType=destinationType,
                dateFormat=dateFormat)


def map_timeseries_panel(database_id: str, view: View, h: int = 8, w: int = 12, x: int = 12, y: int = 8) -> dict:
    return _map_timeseries_panel(database_id, view, 'timeseries', h, w, x, y)


def map_pie_panel(database_id: str, view: View, h: int = 8, w: int = 12, x: int = 12, y: int = 8) -> dict:
    return _map_timeseries_panel(database_id, view, 'piechart', h, w, x, y)


def map_histogram_panel(database_id: str, view: View, h: int = 8, w: int = 12, x: int = 12, y: int = 8) -> dict:
    return _map_timeseries_panel(database_id, view, 'histogram', h, w, x, y)


def _map_timeseries_panel(database_id: str, view: View, panel_type: str, h: int = 8, w: int = 12, x: int = 12,
                          y: int = 8) -> dict:
    datasource = dict(uid=datasource_uid,
                      type='yesoreyeram-infinity-datasource')
    fillOpacity = 0
    if panel_type == 'histogram':
        fillOpacity = 60
    return dict(title=panel_type.capitalize(),
                description=disclaimer,
                type=panel_type,
                datasource=datasource,
                targets=[dict(datasource=datasource,
                              format='table',
                              global_query_id='',
                              hide=False,
                              refId='A',
                              root_selector='',
                              source='url',
                              type='json',
                              url=f'/api/database/{database_id}/view/{view.id}/data',
                              parser='backend',
                              url_options=dict(data='',
                                               method='GET'))],
                gridPos=dict(h=h,
                             w=w,
                             x=x,
                             y=y),
                options=dict(legend=dict(displayMode='list',
                                         placement='bottom',
                                         showLegend=True),
                             tooltip=dict(mode='single',
                                          sort='none')),
                fieldConfig=dict(
                    defaults=dict(color=dict(mode='palette-classic'),
                                  custom=dict(
                                      axisBorderShow=False,
                                      axisCenteredZero=False,
                                      axisColorMode='text',
                                      axisLabel='',
                                      axisPlacement='auto',
                                      barAlignment=0,
                                      drawStyle='line',
                                      fillOpacity=fillOpacity,
                                      gradientMode='none',
                                      hideFrom=dict(legend=False,
                                                    tooltip=False,
                                                    viz=False),
                                      insertNulls=False,
                                      lineInterpolation='linear',
                                      lineWidth=1,
                                      pointSize=5,
                                      scaleDistribution=dict(type='linear'),
                                      showPoints='auto',
                                      spanNulls=False,
                                      stacking=dict(group='A',
                                                    mode='none'),
                                      thresholdsStyle=dict(mode='absolute')))),
                transformations=[dict(id='convertFieldType',
                                      options=dict(fields=dict(),
                                                   conversions=[map_column_conversion(column) for column in
                                                                view.columns]))])


def _map_number_panel(database_id: str, view_id: str, title: str, field: str, x: int = 18, y: int = 0) -> dict:
    datasource = dict(uid=datasource_uid,
                      type='yesoreyeram-infinity-datasource')
    return dict(title=title,
                type='stat',
                datasource=datasource,
                targets=[dict(datasource=datasource,
                              columns=[],
                              filters=[],
                              format='table',
                              global_query_id='',
                              hide=False,
                              refId='A',
                              root_selector='',
                              source='url',
                              type='json',
                              url=f'/api/database/{database_id}/view/{view_id}/statistic',
                              parser='backend',
                              url_options=dict(data='',
                                               method='GET'))],
                fieldConfig=dict(defaults=dict(mappings=[],
                                               thresholds=dict(mode='absolute',
                                                               steps=[dict(color='blue',
                                                                           value=None)]),
                                               unit=''),
                                 overrides=[]),
                transformations=[dict(id='extractFields',
                                      options=dict(delimiter=',',
                                                   source=field,
                                                   format='auto',
                                                   replace=False,
                                                   keepTime=False)),
                                 dict(id='filterFieldsByName',
                                      options=dict(include=dict(names=[field])))],
                gridPos=dict(h=4,
                             w=6,
                             x=x,
                             y=y),
                options=dict(colorMode='background',
                             graphMode='area',
                             justifyMode='auto',
                             orientation='auto',
                             reduceOptions=dict(calcs=[],
                                                fields='/.*/',
                                                values=True),
                             showPercentChange=False,
                             textMode='auto',
                             wideLayout=True))


def map_rows_panel(database_id: str, view_id: str, x: int = 18, y: int = 0) -> dict:
    return _map_number_panel(database_id, view_id, 'Rows', 'total_rows', x, y)


def map_columns_panel(database_id: str, view_id: str, x: int = 18, y: int = 0) -> dict:
    return _map_number_panel(database_id, view_id, 'Variables', 'total_columns', x, y)


def map_statistics_panel(database_id: str, view_id: str, w: int = 12, h: int = 8, x: int = 0, y: int = 8) -> dict:
    datasource = dict(uid=datasource_uid,
                      type='yesoreyeram-infinity-datasource')
    return dict(title='Statistics',
                type='table',
                gridPos=dict(h=h,
                             w=w,
                             x=x,
                             y=y),
                datasource=datasource,
                targets=[dict(datasource=datasource,
                              columns=[],
                              filters=[],
                              format='table',
                              global_query_id='',
                              hide=False,
                              refId='A',
                              root_selector='columns',
                              source='url',
                              type='json',
                              url=f'/api/database/{database_id}/view/{view_id}/statistic',
                              parser='backend',
                              url_options=dict(data='',
                                               method='GET'))],
                options=dict(cellHeight="sm",
                             showHeader=True,
                             footer=dict(countRows=False,
                                         fields="",
                                         reducer=["sum"],
                                         show=False)),
                transformations=[dict(id="organize",
                                      options=dict(excludeByName=dict(),
                                                   includeByName=dict(),
                                                   indexByName=dict(name=0,
                                                                    val_min=1,
                                                                    val_max=2,
                                                                    mean=3,
                                                                    median=4,
                                                                    std_dev=5),
                                                   renameByName=dict(name="Name",
                                                                     mean="Mean",
                                                                     median="Median",
                                                                     std_dev="std.dev",
                                                                     val_min="Minimum",
                                                                     val_max="Maximum")))],
                fieldConfig=dict(defaults=dict(custom=dict(align="auto",
                                                           filterable="true",
                                                           cellOptions=dict(type="auto"),
                                                           inspect=False),
                                               mappings=[],
                                               thresholds=dict(mode="absolute",
                                                               steps=[dict(color="green",
                                                                           value=None),
                                                                      dict(color="red",
                                                                           value=80)
                                                                      ])),
                                 overrides=[]))


def map_overview_panel(database_id: str, view_id: str, x: int = 0, y: int = 4) -> dict:
    datasource = dict(uid=datasource_uid,
                      type='yesoreyeram-infinity-datasource')
    return dict(title='Datasource Preview',
                type='table',
                gridPos=dict(h=8,
                             w=18,
                             x=x,
                             y=y),
                fieldConfig=dict(
                    defaults=dict(
                        color=dict(mode='palette-classic'),
                        custom=dict(axisBorderShow=False,
                                    axisCenteredZero=False,
                                    axisColorMode='text',
                                    axisLabel='',
                                    axisPlacement='auto',
                                    barAlignment=0,
                                    drawStyle='line',
                                    fillOpacity=0,
                                    gradientMode='none',
                                    hideFrom=dict(
                                        legend=False,
                                        tooltip=False,
                                        viz=False),
                                    insertNulls=False,
                                    lineInterpolation='linear',
                                    lineWidth=1,
                                    pointSize=5,
                                    scaleDistribution=dict(
                                        type='linear'),
                                    showPoints='auto',
                                    spanNulls=False,
                                    stacking=dict(group='A',
                                                  mode='none'),
                                    thresholdsStyle=dict(
                                        mode='off'))),
                    overrides=[]),
                options=dict(legend=dict(displayMode='list',
                                         placement='bottom',
                                         showLegend=True,
                                         calcs=[]),
                             tooltip=dict(mode='single',
                                          sort='none')),
                targets=[dict(format='json',
                              columns=[],
                              datasource=datasource,
                              filters=[],
                              global_query_id='',
                              refId='A',
                              root_selector='',
                              source='url',
                              type='json',
                              url=f'/api/database/{database_id}/view/{view_id}/data',
                              parser='backend',
                              url_options=dict(data='',
                                               method='GET'))],
                links=[dict(title='Cite',
                            url=f'{base_url}/database/{database_id}/view/{view_id}/data',
                            targetBlank=True)],
                datasource=datasource)


def map_row(title: str, x: int = 0, y: int = 0) -> dict:
    return dict(collapsed=False,
                title=title,
                type='row',
                panels=[],
                targets=[],
                parser='backend',
                gridPos=dict(h=1,
                             w=24,
                             x=x,
                             y=y))

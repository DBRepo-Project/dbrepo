import logging
import os

from api.exceptions import DashboardNotFound
from client.dashboard import GrafanaClient
from dbrepo.api.dto import Database
from grafana_client.client import GrafanaClientError
from panel import get_panels

base_url = os.getenv('BASE_URL', 'http://localhost')
datasource_uid = os.getenv('JSON_DATASOURCE_NAME', 'dbrepojson0')


def map_link(title: str, url: str, icon: str = 'info') -> dict:
    return dict(targetBlank=True,
                asDropdown=False,
                includeVars=False,
                keepTime=False,
                tags=[],
                type='link',
                icon=icon,
                title=title,
                url=url)


def map_links(database: Database) -> [dict]:
    links = []
    if len(database.identifiers) > 0:
        links.append(map_link('Database', f"{base_url}/pid/{database.identifiers[0].id}"))
    else:
        links.append(map_link('Database', f"{base_url}/database/{database.id}"))
    return links


def find(uid: str):
    """
    Finds a dashboard with the given uid.

    @return The dashboard, if successful. Otherwise, `None`.
    """
    if uid is None:
        return None
    grafana = GrafanaClient().connect()
    try:
        return grafana.dashboard.get_dashboard(uid)
    except GrafanaClientError:
        logging.warning(f"Failed to find dashboard with uid: {uid}")
        return None


def create(database_name: str, uid: str = '') -> dict:
    grafana = GrafanaClient().connect()
    dashboard = dict(uid=uid,
                     title=f'{database_name} Overview',
                     tags=['managed'],
                     timezone='browser',
                     refresh='30m',
                     preload=False,
                     panels=[])
    dashboard['panels'] = []
    payload = dict(folderUid='',
                   overwrite=False,
                   dashboard=dashboard)
    dashboard = grafana.dashboard.update_dashboard(payload)
    logging.info(f"Created dashboard with uid: {dashboard['uid']}")
    return dashboard


def delete(uid: str) -> None:
    grafana = GrafanaClient().connect()
    grafana.dashboard.delete_dashboard(uid)


def update(database: Database) -> None:
    grafana = GrafanaClient().connect()
    dashboard = find(database.dashboard_uid)
    if dashboard is None:
        raise DashboardNotFound(f'Dashboard {database.dashboard_uid} not found')
    dashboard = dashboard['dashboard']
    # update metadata
    if not database.is_dashboard_enabled and 'managed' in dashboard['tags']:
        dashboard['tags'].remove('managed')
    if len(database.identifiers) > 0 and len(database.identifiers[0].titles) > 0:
        dashboard['title'] = database.identifiers[0].titles[0].title
    if len(database.identifiers) > 0 and len(database.identifiers[0].descriptions) > 0:
        dashboard['description'] = database.identifiers[0].descriptions[0].description
    dashboard['links'] = map_links(database)
    # update panels
    dashboard['panels'] = get_panels(dashboard, database)
    payload = dict(folderUid='',
                   overwrite=True,
                   dashboard=dashboard)
    response = grafana.dashboard.update_dashboard(payload)
    logging.info(f"Updated dashboard with uid: {response['uid']}")

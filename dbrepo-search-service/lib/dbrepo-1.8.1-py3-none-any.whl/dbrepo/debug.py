from dbrepo.RestClient import RestClient
from dbrepo.api.dto import QueryDefinition

client = RestClient(endpoint="https://dbrepo1.ec.tuwien.ac.at", username="337195-api", password="f3b55dc8cb8d4221de0978b03a90422ea64fb956")
client.create_subset("597ef7bc-c426-4e92-afce-fabda7f46c42", query=QueryDefinition(table="tindexes", columns=["id"]))
import logging

import mariadb
from mariadb.connections import Connection


class DatabaseClient:

    def __init__(self, username: str, password: str):
        self.username = username
        self.password = password

    def connect(self, hostname: str, port: int, database: str) -> Connection:
        """
        :param hostname: The database hostname
        :param port: The database port
        :param database: The database name

        :return: Connection The database connection.

        :raises mariadb.Error If the connection cannot be established.
        """
        return mariadb.connect(user=self.username, password=self.password, host=hostname, port=port, database=database)

    def get_users(self, hostname: str, port: int, database: str) -> [str]:
        connection = self.connect(hostname, port, database)
        cur = connection.cursor()
        cur.execute(f'SELECT user FROM mysql.user;')
        users = []
        for (user,) in cur:
            users.append(user)
        connection.close()
        return users

    def get_user_grants(self, hostname: str, port: int, database: str, username: str) -> str | None:
        connection = self.connect(hostname, port, database)
        cur = connection.cursor()
        try:
            cur.execute(f'SHOW GRANTS FOR `{username}`@`%`;')
        except mariadb.OperationalError as e:
            logging.error(f'Failed to find grants for user {username}: {e}')
            return None
        grants = None
        for (grant,) in cur:
            grants = grant
        connection.close()
        return grants

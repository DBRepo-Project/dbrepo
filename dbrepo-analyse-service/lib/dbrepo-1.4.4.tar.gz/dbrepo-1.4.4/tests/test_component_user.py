import unittest

from dbrepo.RestClient import RestClient


class UserComponentTest(unittest.TestCase):

    # beforeEach
    def setUp(self):
        self.username = "foo"
        self.password = "bar"
        self.email = "foo.bar@example.com"
        client = RestClient(endpoint="http://localhost")
        # create user if necessary
        for user in client.get_users():
            if user.username == self.username:
                self.user_id = user.id
                return
        response = client.create_user(username=self.username, password=self.password, email=self.email)
        self.user_id = response.id

    def test_create_user_find_whoami_login_basic_oidc(self):
        # find user
        client = RestClient(endpoint="http://localhost", username=self.username, password=self.password)
        response = client.get_user(user_id=self.user_id)
        self.assertEqual(self.username, response.username)
        self.assertEqual(self.user_id, response.id)
        # whoami
        response = client.whoami()
        self.assertEqual(self.username, response)
        # login basic
        response = client.get_jwt_auth(username=self.username, password=self.password)
        self.assertIsNotNone(response.id_token)
        access_token = response.access_token
        self.assertIsNotNone(response.access_token)
        self.assertIsNotNone(response.refresh_token)
        self.assertEqual(0, response.not_before_policy)
        self.assertIsNotNone(response.expires_in)
        self.assertIsNotNone(response.refresh_expires_in)
        self.assertIsNotNone(response.session_state)
        self.assertIsNotNone(response.scope)
        # login oidc
        client = RestClient(endpoint="http://localhost", password=access_token)
        response = client.update_user(user_id=self.user_id, theme="light", language="en")


if __name__ == "__main__":
    unittest.main()
